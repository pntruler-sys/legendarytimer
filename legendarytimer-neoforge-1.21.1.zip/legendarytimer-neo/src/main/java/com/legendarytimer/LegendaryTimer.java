package com.legendarytimer;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.resources.sounds.SimpleSoundInstance;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.sounds.SoundEvents;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.client.event.ClientChatReceivedEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.RegisterClientCommandsEvent;
import net.neoforged.neoforge.client.event.RegisterGuiLayersEvent;
import net.neoforged.neoforge.client.event.RegisterKeyMappingsEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;

/**
 * Manual mode: the mod never sends commands. You type /checkspawns legendary yourself;
 * every reply refines the timer, and the HUD tells you the best moment for the next check.
 */
@Mod(value = LegendaryTimer.MODID, dist = Dist.CLIENT)
public class LegendaryTimer {
    public static final String MODID = "legendarytimer";
    public static final SpawnTracker TRACKER = new SpawnTracker();

    /** Epoch ms of the most useful next manual check, or -1 if none. */
    public static long nextCheck = -1;
    private static boolean alerted = false;
    private static KeyMapping resetKey;

    public LegendaryTimer(IEventBus modBus, ModContainer container) {
        resetKey = new KeyMapping("key.legendarytimer.reset", InputConstants.Type.KEYSYM,
                GLFW.GLFW_KEY_K, "category.legendarytimer");

        modBus.addListener((RegisterKeyMappingsEvent e) -> e.register(resetKey));
        modBus.addListener((RegisterGuiLayersEvent e) -> e.registerAboveAll(
                ResourceLocation.fromNamespaceAndPath(MODID, "hud"), HudOverlay::render));

        NeoForge.EVENT_BUS.addListener(LegendaryTimer::onTick);
        NeoForge.EVENT_BUS.addListener(LegendaryTimer::onChat);
        NeoForge.EVENT_BUS.addListener((RegisterClientCommandsEvent e) ->
                e.getDispatcher().register(Commands.literal("legendarytimer")
                        .then(Commands.literal("reset").executes(c -> { reset(); return 1; }))));
    }

    // Listen only; chat is never cancelled or modified.
    private static void onChat(ClientChatReceivedEvent e) {
        if (!e.isSystem()) return; // ignore player chat so nobody can spoof the timer
        long now = System.currentTimeMillis();
        String s = e.getMessage().getString();
        boolean consumed = TRACKER.handle(s, now);
        if (consumed && s.toLowerCase().contains("time until next spawn")) afterReading();
    }

    private static void onTick(ClientTickEvent.Post e) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;
        while (resetKey.consumeClick()) reset();

        long now = System.currentTimeMillis();
        if (TRACKER.expired(now)) {
            TRACKER.clear();
            nextCheck = -1;
        }
        if (nextCheck > 0 && now >= nextCheck && !alerted) {
            alerted = true;
            mc.getSoundManager().play(SimpleSoundInstance.forUI(SoundEvents.NOTE_BLOCK_PLING, 1.5f));
            msg("Type /checkspawns legendary now");
        }
    }

    private static void afterReading() {
        alerted = false;
        if (TRACKER.done()) {
            nextCheck = -1;
            msg("Spawn time locked in (+/-1s).");
            return;
        }
        nextCheck = TRACKER.nextPollTime(); // -1 if the spawn is too close for a useful check
    }

    private static void reset() {
        TRACKER.clear();
        nextCheck = -1;
        alerted = false;
        msg("Timer reset.");
    }

    private static void msg(String s) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.displayClientMessage(Component.literal("[LegendaryTimer] " + s), true);
    }
}

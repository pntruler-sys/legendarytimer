package com.legendarytimer;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;

import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

public class HudOverlay {
    private static final int PINK = 0xE0407F, BLUE = 0x6A6AFF, CYAN = 0x1FA8E0, TEXT = 0xE8EEFF, DIM = 0x9AA6C8;

    public static void render(GuiGraphics ctx, DeltaTracker tick) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        Font tr = mc.font;
        SpawnTracker t = LegendaryTimer.TRACKER;
        long now = System.currentTimeMillis();

        int w = 190, h = 54;
        int x = ctx.guiWidth() - w - 6, y = 6;

        ctx.fill(x, y, x + w, y + h, 0xB0101830);
        ctx.fill(x, y, x + 2, y + h, 0xFF000000 | PINK);

        // Title with pink -> blue gradient
        String title = "LEGENDARY SPAWN";
        int cx = x + 8;
        for (int i = 0; i < title.length(); i++) {
            float f = i / (float) (title.length() - 1);
            String ch = String.valueOf(title.charAt(i));
            ctx.drawString(tr, ch, cx, y + 4, 0xFF000000 | lerp(PINK, BLUE, f));
            cx += tr.width(ch);
        }

        String acc, win = "", per = "", countdown;
        int accColor = TEXT;
        if (!t.hasData()) {
            acc = "--";
            win = "NO DATA";
            countdown = "--";
        } else {
            if (t.done()) { acc = "EXACT"; accColor = 0x55FF55; }
            else acc = "+/-" + (int) Math.ceil(t.halfWidth() / 1000.0);
            win = "AT " + clock(t.mid());
            per = !t.chance.isEmpty() ? t.chance + " CHANCE" : t.period;
            long rem = t.mid() - now;
            countdown = rem <= 0 ? "NOW" : "IN " + fmt(rem);
        }
        ctx.drawString(tr, acc, x + w - 6 - tr.width(acc), y + 4, 0xFF000000 | accColor);

        ctx.fill(x + 6, y + 15, x + w - 4, y + 16, 0xFF000000 | CYAN);

        ctx.drawString(tr, win, x + 8, y + 20, 0xFF000000 | TEXT);
        ctx.drawString(tr, per, x + w - 6 - tr.width(per), y + 20, 0xFF000000 | DIM);

        ctx.drawString(tr, countdown, x + 8, y + 31, 0xFF000000 | TEXT);
        String a = (t.hasData() && t.done()) ? "LOCKED" : "";
        ctx.drawString(tr, a, x + w - 6 - tr.width(a), y + 31, 0xFF000000 | 0x55FF55);

        // Progress bar
        int bx = x + 8, bw = w - 14, by = y + 44;
        ctx.fill(bx, by, bx + bw, by + 5, 0xFF555C70);
        if (t.hasData()) {
            double frac = 1.0 - (double) (t.mid() - now) / t.initialTotal();
            frac = Math.max(0, Math.min(1, frac));
            ctx.fill(bx, by, bx + (int) (bw * frac), by + 5, 0xFF000000 | CYAN);
        }
    }

    private static final DateTimeFormatter CLOCK =
            DateTimeFormatter.ofPattern("h:mm:ss a", Locale.ENGLISH).withZone(ZoneId.systemDefault());

    /** Spawn time as a clock time on this PC, e.g. 4:12:35 PM. */
    public static String clock(long epochMs) {
        return CLOCK.format(Instant.ofEpochMilli(epochMs));
    }

    private static String fmt(long ms) {
        long s = (ms + 500) / 1000;
        long hh = s / 3600, mm = (s % 3600) / 60, ss = s % 60;
        return (hh > 0 ? hh + "H " : "") + (hh > 0 || mm > 0 ? mm + "M " : "") + ss + "S";
    }

    private static int lerp(int a, int b, float f) {
        int r = (int) (((a >> 16) & 255) * (1 - f) + ((b >> 16) & 255) * f);
        int g = (int) (((a >> 8) & 255) * (1 - f) + ((b >> 8) & 255) * f);
        int bl = (int) ((a & 255) * (1 - f) + (b & 255) * f);
        return (r << 16) | (g << 8) | bl;
    }
}

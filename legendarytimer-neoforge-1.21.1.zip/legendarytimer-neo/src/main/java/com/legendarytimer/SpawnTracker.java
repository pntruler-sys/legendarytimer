package com.legendarytimer;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Parses /checkspawns legendary output and narrows down the exact spawn-attempt time.
 *
 * The server only reports "N minutes" (coarse). Each reading therefore says the true spawn time T
 * lies in [now+N, now+N+1min). We keep the intersection of all readings. Polls are scheduled so
 * the displayed minute is expected to flip at the middle of the current interval, which halves
 * the uncertainty every poll (binary search) until it is ~1 second wide.
 */
public class SpawnTracker {
    public static final long SLACK_MS = 150;          // network/tick jitter tolerance per side
    public static final long PERFECT_WIDTH_MS = 1500; // stop when interval is this narrow
    public static final long MIN_POLL_GAP_MS = 60_000;

    private static final int CI = Pattern.CASE_INSENSITIVE;
    private static final Pattern UNTIL = Pattern.compile("Time until next spawn attempt:\\s*(.+)", CI);
    private static final Pattern TOKEN = Pattern.compile("(\\d+)\\s*(hours?|hrs?|h|minutes?|mins?|m|seconds?|secs?|s)\\b", CI);
    private static final Pattern WINDOW = Pattern.compile(
            "Next attempt between\\s+(\\d{1,2}:\\d{2}\\s*[AP]M)\\s+and\\s+(\\d{1,2}:\\d{2}\\s*[AP]M)\\s*\\((\\w+)\\)", CI);
    private static final Pattern CHANCE = Pattern.compile("Spawn chance:\\s*([\\d.]+%)", CI);

    private boolean has;
    private long lo, hi;          // bounds of true spawn time (epoch ms)
    private long lastUnit = 60_000;
    private long lastReadMs;
    private long initTotal = 1;

    public String windowStart = "", windowEnd = "", period = "", chance = "";

    /** @return true if the line belonged to a /checkspawns legendary reply. */
    public boolean handle(String line, long now) {
        Matcher m = UNTIL.matcher(line);
        if (m.find()) {
            long total = 0, unit = 0;
            Matcher t = TOKEN.matcher(m.group(1));
            while (t.find()) {
                long n = Long.parseLong(t.group(1));
                char c = Character.toLowerCase(t.group(2).charAt(0));
                long u = c == 'h' ? 3_600_000 : c == 'm' ? 60_000 : 1_000;
                total += n * u;
                unit = unit == 0 ? u : Math.min(unit, u);
            }
            if (unit > 0) reading(now, total, unit);
            return true;
        }
        m = WINDOW.matcher(line);
        if (m.find()) {
            windowStart = m.group(1).toUpperCase();
            windowEnd = m.group(2).toUpperCase();
            period = m.group(3).toUpperCase();
            return true;
        }
        m = CHANCE.matcher(line);
        if (m.find()) {
            chance = m.group(1);
            return true;
        }
        return false;
    }

    private void reading(long now, long value, long unit) {
        long nlo = now + value - SLACK_MS;
        long nhi = now + value + unit + SLACK_MS;
        lastUnit = unit;
        lastReadMs = now;
        if (!has) {
            start(now, nlo, nhi);
            return;
        }
        long l = Math.max(lo, nlo), h = Math.min(hi, nhi);
        if (l > h) start(now, nlo, nhi); // inconsistent -> new spawn cycle
        else { lo = l; hi = h; }
    }

    private void start(long now, long nlo, long nhi) {
        lo = nlo; hi = nhi; has = true;
        initTotal = Math.max(1, (nlo + nhi) / 2 - now);
    }

    public boolean hasData() { return has; }
    public long mid() { return (lo + hi) / 2; }
    public long halfWidth() { return (hi - lo) / 2; }
    public long initialTotal() { return initTotal; }
    public boolean done() { return has && (hi - lo) <= PERFECT_WIDTH_MS; }

    /** Drop data once the spawn attempt has passed. */
    public boolean expired(long now) { return has && now > hi + 2000; }

    public void clear() { has = false; }

    /**
     * Next poll time (epoch ms) placed so the shown minute flips at the middle of the interval.
     * Returns -1 if no useful poll remains before the spawn.
     */
    public long nextPollTime() {
        if (!has) return -1;
        long earliest = lastReadMs + MIN_POLL_GAP_MS;
        long k = (long) Math.floor((mid() - earliest) / (double) lastUnit);
        if (k < 1) return -1;
        return mid() - k * lastUnit;
    }
}

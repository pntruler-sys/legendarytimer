# Legendary Timer (NeoForge 1.21.1, client-side, MANUAL mode)

The mod never types commands. You run /checkspawns legendary yourself.
- Every reply is read and refines the spawn time (accuracy shown as +/-N on the HUD).
- The HUD shows "CHECK IN m:ss"; at zero you get a ping + "CHECK NOW!". Checking then narrows the time the most.
- At ~+/-1s the HUD shows LOCKED. Press K (or /legendarytimer reset) after the spawn to start fresh.

Build: JDK 21, run `gradle wrapper` once, then `./gradlew build`. Jar: build/libs/legendarytimer-1.0.0.jar -> mods folder.
Other MC version? Change `version` in build.gradle (NeoForge) and the version ranges in neoforge.mods.toml.
